import os
import logging

logging.getLogger().setLevel(logging.WARNING)

def lambda_handler(event, context):
    print("I'm running!")
